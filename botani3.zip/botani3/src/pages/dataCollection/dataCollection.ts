import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the SpecialPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'dataCollection',
  templateUrl: 'dataCollection.html',
})
export class DataCollection {
  isLeafingType: boolean;
  isFruitingType: boolean;
  isFloweringType: boolean;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.isLeafingType = true;
    this.isFruitingType = false;
    this.isFloweringType = true;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DataCollection');
  }

}
