angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController.leaderboard', {
    url: '/myleaderboard',
    views: {
      'tab1': {
        templateUrl: 'templates/leaderboard.html',
        controller: 'leaderboardCtrl'
      }
    }
  })

  .state('tabsController.personalForest', {
    url: '/collection',
    views: {
      'tab3': {
        templateUrl: 'templates/personalForest.html',
        controller: 'personalForestCtrl'
      }
    }
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.leaderboard2', {
    url: '/globalleaderboard',
    views: {
      'tab1': {
        templateUrl: 'templates/leaderboard2.html',
        controller: 'leaderboard2Ctrl'
      }
    }
  })

  .state('signup', {
    url: '/signup',
    templateUrl: 'templates/signup.html',
    controller: 'signupCtrl'
  })

  .state('logIn', {
    url: '/login',
    templateUrl: 'templates/logIn.html',
    controller: 'logInCtrl'
  })

  .state('notificationSettings', {
    url: '/notifications',
    templateUrl: 'templates/notificationSettings.html',
    controller: 'notificationSettingsCtrl'
  })

  .state('settings', {
    url: '/settings',
    templateUrl: 'templates/settings.html',
    controller: 'settingsCtrl'
  })

  .state('tabsController.map', {
    url: '/map',
    views: {
      'tab2': {
        templateUrl: 'templates/map.html',
        controller: 'mapCtrl'
      }
    }
  })

  .state('leafiness', {
    url: '/leafiness',
    templateUrl: 'templates/leafiness.html',
    controller: 'leafinessCtrl'
  })

  .state('fruiting', {
    url: '/fruiting',
    templateUrl: 'templates/fruiting.html',
    controller: 'fruitingCtrl'
  })

  .state('flowering', {
    url: '/flowering',
    templateUrl: 'templates/flowering.html',
    controller: 'floweringCtrl'
  })

  .state('rewardScreen', {
    url: '/rewardScreen',
    templateUrl: 'templates/rewardScreen.html',
    controller: 'rewardScreenCtrl'
  })

  .state('confirmationScreen', {
    url: '/confirmationScreen',
    templateUrl: 'templates/confirmationScreen.html',
    controller: 'confirmationScreenCtrl'
  })

$urlRouterProvider.otherwise('/page1/map')


});