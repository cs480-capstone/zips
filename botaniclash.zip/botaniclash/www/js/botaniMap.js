/* !!! IMPORTANT: Rename "mymodule" below and add your module to Angular Modules above. */

angular.module('botaniMap', [])

.service('mapSrv', [function(){
    
    

}]);

